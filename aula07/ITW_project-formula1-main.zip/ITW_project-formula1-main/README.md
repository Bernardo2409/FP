# ITW_project-formula1

Done by:
  - Alexandre Cotorobai 107849
  - João Dourado 108636

Grade: 17.5

Site: https://alexandrecotorobai.github.io/ITW_project-formula1/
(Only 100% functional on UA's network)
